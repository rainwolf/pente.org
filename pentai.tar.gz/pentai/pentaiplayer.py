#!/usr/bin/env python
'''
from guppy import hpy
h = hpy()
h.setref()
'''

import pentai.base.rules as r_m
import pentai.base.game as g_m

import time

from pentai.ai.ai_player import *
#from pentai.db.evaluator import *
from pentai.db.ai_factory import *
from pentai.db.openings_book import *
from pentai.db.games_mgr import *
import pentai.db.zodb_dict as z_m

import pentai.ai.ab_game as abg_m

import sys

import random

import gc

from urllib import urlopen
import time, os


if __name__ == "__main__":
    debug = True

    random.seed()
    z_m.set_db("db.fs")

    board_size = 19
    aip_m.set_skip_openings_book(False) # For deterministic results

    password = os.environ['PENTAIPASSWORD']

    try:
        while True:
            try:
                # dashStr = urlopen("https://development.pente.org/gameServer/mobile/aiIndex.jsp?name=computer&password="+password).read()
                dashStr = urlopen("https://pente.org/gameServer/mobile/aiIndex.jsp?name=computer&password="+password).read()
                if debug:
                    print dashStr
                dashLines = dashStr.split("\n")
                i = 0
                if "End" in dashLines[0]:
                    if debug:
                        print "Going to sleep for a few seconds"
                    time.sleep(2)
                for dashLine in dashLines:
                    try:
                        if "End" in dashLine:
                            if debug:
                                print "Going to sleep for a few seconds"
                            time.sleep(2)
                            break
                        # gameStr = urlopen("https://development.pente.org/gameServer/mobile/aiGame.jsp?name2=computer&password2="+password+"&gid=" + dashLine).read()
                        gameStr = urlopen("https://pente.org/gameServer/mobile/aiGame.jsp?name2=computer&password2="+password+"&gid=" + dashLine).read()
                        print gameStr
                        gameLines = gameStr.split("\n")
                        for gameLine in gameLines:
                            if "gid=" in gameLine:
                                gid = gameLine[4:]
                            if "gameName=" in gameLine:
                                gameType = gameLine[9:]
                            if "moves=" in gameLine:
                                movesList = gameLine[6:].split(",")
                            if "difficulty=" in gameLine:
                                difficulty = int(gameLine[11:])
                            if "EndOfSettingsParameters" in gameLine:
                                break

                        if not "Pente" in gameType:
                            continue
                        if "Pente-Rated" in gameType:
                            gameTypeStr = 't'
                        # elif "Keryo-Pente-Rated" in gameType:
                        #     gameTypeStr = 'l'
                        elif "Gomoku" in gameType:
                            gameTypeStr = '5'
                        elif "Pente" in gameType:
                            gameTypeStr = 's'
                        if debug:
                            print "gameTypeStr: " + gameTypeStr
                        # elif "Keryo-Pente" in gameType:
                        #     gameTypeStr = 'k'
                        r = r_m.Rules(board_size, gameTypeStr)
                        # r = r_m.Rules(board_size, gameType)
                        aiGenome = AIGenome("aiPlayer")
                        aiGenome.use_openings_book = True
                        aiGenome.judgement = 99
                        if (len(movesList) < 3) and r.tournament_rule:
                            aiGenome.mmpdl = 25
                            if difficulty > 5:
                                aiGenome.narrowing = 3
                        games_mgr = GamesMgr()
                        # openings_book = OpeningsBook()
                        aiFactory = AIFactory()
                        # difficulty = 1
                        aiGenome.max_depth = difficulty
                        aiPlayer = aiFactory.create_player(aiGenome)
                        if len(movesList) % 2 == 0:
                            game = games_mgr.create_game(r, aiPlayer, None)
                        else:
                            game = games_mgr.create_game(r, None, aiPlayer)
                        for move in movesList:
                            intMove = int(move)
                            moveX = intMove / 19
                            moveY = intMove % 19
                            game.make_move([moveX, moveY])
                        if debug:
                            print "movesList: %r" % movesList
                        p = game.get_current_player()
                        turn, prev_move, m = p.do_the_search()
                        resultMove = m[0]*19 + m[1]

                        if debug:
                            print "move: " +str(resultMove)
                        # gameStr = urlopen("https://development.pente.org/gameServer/tb/game?name2=computer&password2="+password+"&command=move&mobile=&gid=" + gid + "&moves=" + str(resultMove) + "&message=").read()
                        gameStr = urlopen("https://pente.org/gameServer/tb/game?name2=computer&password2="+password+"&command=move&mobile=&gid=" + gid + "&moves=" + str(resultMove) + "&message=").read()
                        if debug:
                            print gameStr
                    except Exception, e:
                        pass
            except Exception, e:
                pass


    except KeyboardInterrupt:
        quit()


     
      
