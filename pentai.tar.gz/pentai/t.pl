#!/usr/bin/perl -pi.bak
s/BLACK/P1/g;
s/WHITE/P2/g;
