rm openings_book.so

rm openings_book.py

ln -s openings_book.pyx            openings_book.py

