rm openings_book.{py,pyc}

