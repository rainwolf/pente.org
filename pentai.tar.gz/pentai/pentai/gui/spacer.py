from kivy.uix.widget import Widget

class HSpacer(Widget):
    pass

class VSpacer(Widget):
    pass

