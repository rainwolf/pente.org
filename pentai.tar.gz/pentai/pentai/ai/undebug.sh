rm ab_game.py[c]
rm ab_state.py[c]
rm alpha_beta.py[c]
rm openings_mover.py[c]
rm utility_calculator.py[c]
# rm utility_stats.py[c]
rm length_factor.py[c]
rm priority_filter.py[c]
rm priority_filter_2.py[c]
rm priority_filter_3.py[c]
rm priority_filter_4.py[c]
rm priority_filter_5.py[c]
rm heuristic_filter.py[c]
rm killer_filter.py[c]
rm utility_filter.py[c]

rm ab_game.py
rm ab_state.py
rm alpha_beta.py
rm openings_mover.py
rm utility_calculator.py
# rm utility_stats.py
rm length_factor.py
rm priority_filter.py
rm priority_filter_2.py
rm priority_filter_3.py
rm priority_filter_4.py
rm priority_filter_5.py
rm heuristic_filter.py
rm killer_filter.py
rm utility_filter.py
