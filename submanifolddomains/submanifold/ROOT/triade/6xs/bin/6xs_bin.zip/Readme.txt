A few directions for the use of 6xs.

1) When verifying a digital signature of a file, 
first select the signed file, click verify and when a 
open dialog pops up, select the digital signature file.
2) Don 't sign an email message twice.
3) If an email is encrypted without public key and 
decryption fails (due to a wrong password), click again 
on the message to retrieve it from the server and try 
again. 
4) The button with the key on it is used to include your 
public keys in an email message, and the same button on 
the InBox tab is used to store the th public keys that 
were send along.
5) The edit box next to the connect button on the 
ComLink tab is used to enter the servers' ip-address, 
his listen-radiobutton must be clicked to establish a 
connection.
6) When generating (public) keys, the .exe files of 
the keygenerators must be located in the same directory 
as 6xs.
7) Everything else is pretty much straightforward.