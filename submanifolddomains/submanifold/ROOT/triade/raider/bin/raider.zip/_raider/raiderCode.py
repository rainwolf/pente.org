Version = '20070426'

# Original author: Walied Othman <rainwolf@submanifold.be>
# This wouldn't be without the great libgmail http://libgmail.sourceforge.net/
# nor without python http://www.python.org
# or freepascal http://www.freepascal.org

#ToDo
# - lots 
# - ...
import subprocess, getpass, os, libgmail, zipfile, hashlib
import distutils.file_util, email, mimetypes, binascii, base64

# Returns a list of emailaddresses that you stored using maintainchildren
# When the list is empty a chance to add addresses is offered
def getChildren():
  cmd='GetChildren'
  f=subprocess.Popen([cmd],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
  password = 'dummy'
  if os.path.exists('Children.txt'):
    print 'Enter the password to decrypt your children'
    password = getpass.getpass()
  f.stdin.write(password+'\n')
  f.stdin.close()
  f.wait()
  children=[]
  for line in f.stdout:
    children.append(line.strip())
  f.stdout.close()
  if children==['- wrong password']:
    answer = raw_input('Wrong password! Retry? (y/n)')
    if answer == 'y':
      return getChildren()
    else:
      children=[]
  if children==['- no children']:
    print 'no emailaddresses, go and multiply thyself first (i.e. run MaintainChildren)'
    answer = raw_input('run now? (y/n): ')
    if answer == 'y':
      f=os.system('MaintainChildren')
      f.wait()
      return getChildren()
    else:
      children=[]
  return children

# Verifies the signature of filename
# returns True if the signature is valid and False otherwise
def verifySignature(filename):
  cmd='VerifySignature'
  f=subprocess.Popen([cmd],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
  f.stdin.write(filename+'\n')
  f.stdin.close()
  f.wait()
  output=[]
  for line in f.stdout:
    output.append(line.strip())
  f.stdout.close()
  if output==['valid']:
    return True
  else:
    return False

# Returns True if the sha256-hash of the file filename is 
# in the database db, and False otherwise
def inDB(filename, db):
  if not os.path.exists(db):
    return False
  hash = base64.b64encode(hashlib.sha256(open(filename,'r+b').read()).digest())
  if (hash+'\n') in open(db,'r').readlines():
    return True
  return False
  
# Adds the sha256-hash of the file filename to the database db
# if the hash isn't already in there
def addToDB(filename, db):
  hash = base64.b64encode(hashlib.sha256(open(filename,'r+b').read()).digest())
  if not os.path.exists(db):
    open(db,'w').write(hash+'\n')
  else:
    dB = open(db,'r').readlines()
    if not ((hash+'\n') in dB):
      dB.append(hash+'\n')
      f = open(db,'w')
      for line in dB:
        f.write(line)
      f.close()

# Syncs your PayLoadsDir to the PayLoadsDB, 
# useful after trickling a PayloadsDB-file and removing obsolete files
def syncPayLoadsToDB():
  payLoadsDir = os.listdir('PayLoads')
  dB = open('PayLoadsDB.txt','r').readlines()
  for line in payLoadsDir:
    if not line.endswith('.sig'):
      fname = os.path.join(os.getcwd(),'PayLoads',line)
      hash = base64.b64encode(hashlib.sha256(open(fname,'r+b').read()).digest())
      if not ((hash+'\n') in dB):
        os.remove(fname)
        os.remove(fname+'.sig')

# Verify the files and signatures in the PayLoadsDir,
# Files and Signatures that aren't valid are removed.
def verifyPayLoadsDir():
  payLoadsDir = os.listdir('PayLoads')
  for line in payLoadsDir:
    if not line.endswith('.sig'):
      fname = os.path.join(os.getcwd(),'PayLoads',line)
      if not verifySignature(fname):
        os.remove(fname)
        os.remove(fname+'.sig')

# Verify if the content of the zipfile is valid, the zipfile must contain exactly 2 files, 
# one must have the same name + the extension '.sig', and the '.sig'-file must contain
# exactly 2 lines which have to be the valid signature of the other file.
# otherwise False is returned.
def verifyZipContent(filename):
  if not os.path.exists('temp'):
    os.mkdir('temp')
  zip = zipfile.ZipFile(filename, 'r')
  contents = zip.namelist()
  if (len(contents)<>2):
    zip.close()
    print '- The zip-file structure is invalid, signature verification failed'
    return False
  if not ((contents[0]==(contents[1]+'.sig')) or (contents[1]==(contents[0]+'.sig'))):
    zip.close()
    print '- The zip-file structure is invalid, signature verification failed'
    return False
  for name in contents:
    file(os.path.join(os.getcwd(),'temp',name), 'wb').write(zip.read(name))
  zip.close()
  if contents[0].endswith('.sig'):
    sigCheck = verifySignature(os.path.join(os.getcwd(),'temp',contents[1]))
    name = contents[1]
  else:
    sigCheck = verifySignature(os.path.join(os.getcwd(),'temp',contents[0]))
    name = contents[0]
  if sigCheck:
    print '- signature of '+name+' is valid'
  else:
    print '- signature of '+name+' is invalid'
  for name in contents:
    os.remove(os.path.join(os.getcwd(),'temp',name))
  return sigCheck

# filename is forwarded to your children, using the google account that corresponds to 
# username and password.  An additional password is prompted to decrypt your children.
def forwardSignedPayLoad(username,password,filename):
  ga = libgmail.GmailAccount(username, password)
  try:
    ga.login()
  except libgmail.GmailLoginFailure:
    print "Login failed. (Wrong username/password?)"
    raw_input("Exiting... Press Enter to Close")
    raise SystemExit
  else:
    print "Login successful"
  children = getChildren()
  total = len(children)
  i=0
  names = []
  crc = hex(binascii.crc32(open(filename,'r+b').read()))[3:]
  names.append(filename)
  for child in children:
    i += 1
    msg = libgmail.GmailComposedMessage(child, '[raider] trickle - '+crc, '', filenames = names)
    if ga.sendMessage(msg):
      print " "*60+"\r", 
      print '('+str(i)+'/'+str(total)+') - Sent payload to '+child+'\r',
    else:
      print ' sending payload failed.\r',
  print ''

############ ToFinish ####################
# Processing of the received zipfile
# - .py and .exe are considered updates and directly installed
# - PayloadsDB.txt is directly installed and the PayLoadsDir is immediately synced
# - SourceDBUpdate is immediately applied
# - message.txt is displayed
# - Payloads are installed and the PayloadsDB updated immediately
# - The user is informed of uknown content with a verified signature
def processContent(filename):
  zip = zipfile.ZipFile(filename, 'r')
  contents = zip.namelist()
  for name in contents:
    file(os.path.join(os.getcwd(),'temp',name), 'wb').write(zip.read(name))
  zip.close()
  if contents[0].endswith('.sig'):
    fname = contents[1]
  else:
    fname = contents[0]
  if fname.endswith('.py') or fname.endswith('.exe'):
    print '- Content appears to be an update, installing '+fname
    if os.path.exists(os.path.join(os.getcwd(),fname)):
      os.remove(os.path.join(os.getcwd(),fname))
    distutils.file_util.move_file(os.path.join(os.getcwd(),'temp',fname),os.path.join(os.getcwd(),fname))
    os.remove(os.path.join(os.getcwd(),'temp',fname+'.sig'))
    return
  if fname == 'PayLoadsDB.txt':
    print '- Content appears to be an updated PayLoadsDB-file'
    if os.path.exists(os.path.join(os.getcwd(),fname)):
      os.remove(os.path.join(os.getcwd(),fname))
    distutils.file_util.move_file(os.path.join(os.getcwd(),'temp',fname),os.path.join(os.getcwd(),fname))
    print '- Syncing PayLoadsDir to the new PayLoadsDB-file'
    syncPayLoadsToDB()
    os.remove(os.path.join(os.getcwd(),'temp',fname+'.sig'))
    return
  if fname == 'SourceDBupdate.txt':
    print '- Content appears to be a SourceDB-update'
    print '- Updating SourceDB-file'
    if os.path.exists('SourceDB.txt'):
      dB = open('SourceDB.txt','r').readlines()
      update = open(os.path.join(os.getcwd(),'temp',fname),'r').readlines()
      f = open('SourceDB.txt','w+b')
      for line in dB:
        if (line in update):
          f.write(line+'\n')
      f.close()
    os.remove(os.path.join(os.getcwd(),'temp',fname))
    os.remove(os.path.join(os.getcwd(),'temp',fname+'.sig'))
    return
  if fname == 'message.txt':
    print '- Content appears to be a message'
    print '----- begin message -----'
    for line in open(os.path.join(os.getcwd(),'temp',fname),'r').readlines():
      print line.strip()
    print '-----  end message  -----'
    raw_input('\n Press Enter to continue...')
    os.remove(os.path.join(os.getcwd(),'temp',fname))
    os.remove(os.path.join(os.getcwd(),'temp',fname+'.sig'))
    return
############ ToFinish ####################
######### This section contains the specific type of files
######### you wish to spread and what to do with them
  if fname.endswith('.pld'):
    print '- Content appears to be a payload, installing...'
    distutils.file_util.move_file(os.path.join(os.getcwd(),'temp',fname),os.path.join(os.getcwd(),'PayLoads',fname))
    distutils.file_util.move_file(os.path.join(os.getcwd(),'temp',fname+'.sig'),os.path.join(os.getcwd(),'PayLoads',fname+'.sig'))
    addToDB(os.path.join(os.getcwd(),'PayLoads',fname), 'PayLoadsDB.txt')
    return
############ ToFinish ####################
  print '- Content is unknown to me: '+fname
  print ' The signature was verified, it was issued by the Source'
  print ' Please examine manually, the unpacked file and signature are located in'
  print '  '+os.path.join(os.getcwd(),'temp')
  
############ To Check ###############
# Download unread emails with subjects that contain "[raider] trickle" and have .zip attachments
# If the signature checks out the file is processed and a hash is stored to remember that we 
# already downloaded this one. Otherwise the downloaded file and email is deleted.
def downloadFromTheSource(username,password):
  if not os.path.exists('temp'):
    os.mkdir('temp')
  ga = libgmail.GmailAccount(username, password)
  try:
    ga.login()
  except libgmail.GmailLoginFailure:
    print "Login failed. (Wrong username/password?)"
    raw_input("Exiting... Press Enter to Close")
    raise SystemExit
  else:
    print "Login successful"
  folder = ga.getMessagesByQuery('in:inbox AND is:unread AND subject:"[raider] trickle" AND has:attachment AND filename:".zip"', allPages = True)
  for thread in folder:
    for msg in thread:
      rawmsg = email.message_from_string(msg.source)
      counter = 1
      for part in rawmsg.walk():
        if part.get_content_maintype() == 'multipart':
          continue
        filename = part.get_filename()
        if not filename:
          ext = mimetypes.guess_extension(part.get_content_type())
          if not ext:
            ext = '.bin'
          filename = 'part-%03d%s' % (counter, ext)
        counter += 1
        if filename.endswith('.zip'):
          fname = os.path.join(os.getcwd(),'temp',filename)
          f = open(fname,'wb')
          f.write(part.get_payload(decode=True))
          f.close() 
          if inDB(fname, 'SourceDB.txt'):
            os.remove(fname)
            print '- file already downloaded'
          else:
            if verifyZipContent(fname):
              addToDB(fname,'SourceDB.txt')
              print 'Signature verified. Examining contents...'
              processContent(fname)
              forwardSignedPayLoad(username, password, fname)
              os.remove(fname)
            else:
              print 'Signature invalid!'
              print 'Deleting message and downloaded file.'
              ga.trashMessage(msg)
              os.remove(fname)
