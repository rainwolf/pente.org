import raiderCode, raiderSourceCode, os, glob

# list the files in the current directory
folder = os.listdir(os.getcwd())
print ''
i=0
for file in folder:
  print '('+str(i) +') '+file
  i += 1
print ''
index = raw_input('Which file do you want to sign: ')
filename = folder[int(index)]
# sign the selected file
raiderSourceCode.signAndZip(os.path.join(os.getcwd(),filename))
# verify and process the file
if raiderCode.verifyZipContent(os.path.join(os.getcwd(),'raider.zip')):
  raiderCode.processContent(os.path.join(os.getcwd(),'raider.zip'))
# cleanup
for filename in glob.glob(os.path.join(os.getcwd(),'temp','*')):
  os.remove(os.path.join(os.getcwd(),'temp',filename))
os.removedirs('temp')
os.remove('raider.zip')
for filename in glob.glob('*.pyc') :
  os.remove(filename)
raw_input("Press Enter ")
