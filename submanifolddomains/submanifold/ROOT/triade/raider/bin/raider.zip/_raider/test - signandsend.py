import raiderSourceCode, raiderCode, os

# list the files in the current directory
folder = os.listdir(os.getcwd())
print ''
i=0
for file in folder:
  print '('+str(i) +') '+file
  i += 1
print ''
index = raw_input('Which file do you want to sign: ')
filename = folder[int(index)]
# sign the selected file
raiderSourceCode.signAndZip(os.path.join(os.getcwd(),filename))
filename = os.path.join(os.getcwd(),'raider.zip')
# send out the signed file = trickle the trickle through the network
raiderCode.forwardSignedTemplate('yourusername@gmail.com','yourpassword',filename)
os.remove(filename)
raw_input(" Press Enter ")