Version = '20070426'

# Original author: Walied Othman <rainwolf@submanifold.be>
# This wouldn't be without the great libgmail http://libgmail.sourceforge.net/
# nor without python http://www.python.org
# or freepascal http://www.freepascal.org

#ToDo
# - lots 
# - ...
import subprocess, getpass, os, zipfile

def signAndZip(filepathname): 
  cmd='CreateSignature'
  f=subprocess.Popen([cmd],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
  f.stdin.write(filepathname+'\n')
  print 'Enter the password to decrypt your private key. '
  password = getpass.getpass()
  f.stdin.write(password+'\n')
  somethingRandom = getpass.getpass('Enter something random: ')
  f.stdin.write(somethingRandom+'\n')
  f.wait()
  for line in f.stdout.readlines():
    output = line.strip()
  f.stdin.close()
  f.stdout.close()
  if output == 'wrong password!':
    raw_input('Wrong password! Press enter to retry. ')
    signAndZip(filepathname)
  else:
    (path, filename) = os.path.split(filepathname)
    zip = zipfile.ZipFile(os.path.join(os.getcwd(),'raider.zip'), 'w',zipfile.ZIP_DEFLATED)
    zip.write(filepathname, filename)  
    zip.write(filepathname+'.sig', filename+'.sig')
    zip.close()
    os.remove(filepathname+'.sig')
