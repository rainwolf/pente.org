This script is more a framework to spread files using gmail in a tree-like network. It allows 
the root to spread digitally signed files through the network, to its children, and each child 
will automatically verify the digital signature, process the contents and spread it to their 
own children.

Clients should only have: raiderCode.py, VerifySignature, MaintainChildren, GetChildren.
The others: GenerateKeys, CreateSignature, LoadKeys and ChangePassword are for the 
rootnode, the node that signs and spreads the files.

First (Setup) run: GenerateKeys and then LoadKeys. Compile VerifySignature before you give it to the world.
Don't ever run GenerateKeys again, the keys that you generated are permanent.
- MaintainChildren: creates an encrypted list of children. Adding/Removing/Viewing are the supported routines.
- VerifySignature: verifies an ECDSA digital signature with its hardcoded keys, use only from raiderCode.py
- GetChildren: returns a list of your encrypted children, use only from raiderCode.py
The client only needs to call one function "downloadFromTheSource(username,password)" that handles everything 
automatically. "verifyPayLoadsDir()" is an extra function that verifies all the digital signatures in the 
payloads-directory and removes invalid signatures along with their signed files.

The root can issue 
- signed updates to the script and executables
- signed messages (message.txt)
- a signed database of payloads to which the clients needs to sync its payloads (remove old payloads)
- a signed update/cleanup of a db-file that tracks downloaded files and remove old entries
- a signed payload, whatever you want it to be, you need to adapt the script to your specific needs 
  regarding this though

There are usage examples provided. The password to decrypt the private key is quite simply "password".
have fun