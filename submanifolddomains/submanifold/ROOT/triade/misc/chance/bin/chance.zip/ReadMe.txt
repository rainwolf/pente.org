It's just like playing the lottery, whenever you feel like it, press enter, and the program generates random numbers, checks them for common factors with the RSA prize numbers and that's it.
It's written in FreePascal, I expect it to compile and run wherever FreePascal runs.  The executable in this zip will only run on windows I 'm afraid.
Should you be so lucky that one is found, then that factor will be written to the screen (quick, grab a pen and paper and write the number down, just in case...) and to a text file.
The prize money for each number is
Name:         RSA-704
Prize:        $30000
Name:         RSA-768
Prize:        $50000
Name:         RSA-896
Prize:        $75000
Name:         RSA-1024
Prize:        $100000
Name:         RSA-1536
Prize:        $150000
Name:         RSA-2048
Prize:        $200000
Aint that sweet?
Mail any suggestions to rainwolf@submanifold.be
have fun