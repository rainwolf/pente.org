The screen of my Dell Inspiron 4150 is set to turn off after some time.  Sometimes when I move the mouse, press a key, 
click, or whatever, the screen wouldn't turn back on.  Well the screen would, but not the backlight.  If I looked closely 
I could still make out what 's on the screen, very faint but not enough.  My only options were to reboot, standby, 
wait 3 hours for the screen to turn off again and try again or set that time to one minute if I could make out enough 
on the screen to do so and try again after one minute.  

Maybe you have the same problem as I do, but I couldn't find anything on the web on this.  

Well, I 've had it, and with some research on usenet I've made this little thingy that 'll turn off your screen on a click 
(some modifications can easily be made to do that on startup) and turn it back on again on another click or on moving 
your mouse.  Delphi source code included.

Enjoy.

