#!/usr/bin/env python
Version = '20161104'

# Original author: Walied Othman <rainwolf@submanifold.be>
# IMAP and SMTP support: Ray Cathcart <gknujon@vantcm.com>
# This wouldn't be without python
# http://www.python.org

#ToDo
# - allow user to configure SMTP port and/or server
# - forward spam without downloading it
# - catch exceptions
# - ...

import imaplib, os, datetime, zipfile, sys, smtplib, re, string, socket, tempfile, shutil, getpass
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders


# RLC - I found this sendMail subroutine on dzone.com. Modified it to work with
#       google's authentication.
#to python files mail smtp by manatlan on Wed Sep 21 16:30:49 -0400 2005
# to        => [list] of addresses for "To:" field
# subject   => string for "Subject:" field
# text      => string for body of email
# files     => [list] of files to attach using MIME
# server    => string containing SMTP server address (e.g. smtp.gmail.com)
# smtp_user => string containing the user name (unauthenticated use "")
# smtp_pass => string containing the password (unauthenticated use "")
def sendMail(to, subject, text, files, server, smtp_user, smtp_pass):
    assert type(to)==list
    assert type(files)==list
    fro = "<"+smtp_user+">"
    
    msg = MIMEMultipart()
    msg['From'] = fro
    msg['To'] = COMMASPACE.join(to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    # Add text part to message
    result = msg.attach( MIMEText(text) )

    # Encode and add files to message
    for file in files:
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(file,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"'
                       % os.path.basename(file))
        result = msg.attach(part)
        
    socket.setdefaulttimeout(timeOut)
    # ISPs often block port 25, so use gmail's port 587 (which is technically
    # more correct anyway since we are using tls)
    smtp = smtplib.SMTP(server, 587)
    if smtp_user != "":
        # RLC - This authentication works with gmail - I have not tested it elsewhere.
        # first you have to say 'hi' to the server
        result = smtp.ehlo()
        # start the secure session. Google requires it, and you won't get in
        # trouble from your ISP for sending "SPAM".
        result = smtp.starttls()
        # say hello again
        result = smtp.ehlo()
        # login
        result = smtp.login(smtp_user, smtp_pass)
    # Send off the message
    smtp.sendmail(fro, to, msg.as_string() )
    smtp.quit() # to be uncommented with python 2.6 / 3.0


def verifyLang(langSet, testSet):
    foundMatch = True
    for word in testSet:
      foundMatch = foundMatch and (word in langSet)
      if not foundMatch:
        break
    return foundMatch
   
   
def nextAvailable(path, msgn,extn):
    j=0
    while os.path.exists(os.path.join(tempfile.gettempdir(),path,msgn+str(j)+'.'+extn)):
      j=j+1
    return os.path.join(tempfile.gettempdir(),path,msgn+str(j)+'.'+extn)

    
    
#----- begin no-sync zone

print ''
print 'This is gspamcop, version '+str(Version)
if ('-h' in sys.argv) or (len(sys.argv) == 1):
  print 'Usage: gspamcop.py -l username -p password -r (KnujOn-)reportingaddress -rsc spamcopreportingaddress'
  print '       -p can be omitted to interactively enter a password'
  print 'Optional parameters:'
  print '- set the time out for the smtp connection to a custom value, default=10'
  print ' -timeOut 20'
  print '- set maxReportSize to the maximal number of spams you want each email (report) to contain, default=50'
  print '  This only applies to stockjunk, gspamcop now obeys spamcop-submission rules'
  print ' -maxReportSize 17'
  print '- set if you want all your spam, read AND unread, reported'
  print ' -processAllSpam'
  print '- set if you want your reports automatically trashed'
  print ' -autoTrashReports'
  print '- set if you want your spam automatically trashed'
  print ' -autoTrashSpam'
  print '- set if you want the SEC delivery notifications automatically deleted'
  print ' -autoTrashSec'
  print '- set if you want your stockjunk reported somewhere else'
  print ' -s stockjunkreportingaddress'
  print '- set if you don''t want any interaction'
  print ' -automate'
  raw_input('Exiting, press Enter...')
  raise SystemExit
if '-l' in sys.argv:
  username = sys.argv[sys.argv.index('-l')+1]
else:
  print 'Error: No Username Found!'
  print '-> usage: gspamcop.py -l username'
  raw_input('Exiting, press Enter...')
  raise SystemExit
if '-p' in sys.argv:
  try:
    password = sys.argv[sys.argv.index('-p')+1]
    if password.startswith("-"):
      password = getpass.getpass('Enter password for '+username+' : ')
  except IndexError:
    password = getpass.getpass('Enter password for '+username+' : ')
else:
  print 'No Password Found!'
  print '-> usage: gspamcop.py -p password.'
  print '- Enter your password now or press Enter to exit.'
  password = getpass.getpass('Enter password for '+username+' : ')
  if password == "":
    raise SystemExit
if '-r' in sys.argv:
  to = sys.argv[sys.argv.index('-r')+1]
else:
  print 'Error: No (KnujOn)Reporting Address Found!'
  print '-> usage: gspamcop.py -r reportingaddress'
  raw_input('Exiting, press Enter...')
  raise SystemExit
if '-rsc' in sys.argv:
  toCC = sys.argv[sys.argv.index('-rsc')+1]
else:
  print 'Error: No SpamCop Reporting Address Found!'
  print '-> usage: gspamcop.py -rsc spamcopreportingaddress'
  raw_input('Exiting, press Enter...')
  raise SystemExit
if '-maxReportSize' in sys.argv:
  maxReportSize = int(sys.argv[sys.argv.index('-maxReportSize')+1])
else:
  maxReportSize = 50
if '-timeOut' in sys.argv:
  timeOut = int(sys.argv[sys.argv.index('-timeOut')+1])
else:
  timeOut = 10
if '-processAllSpam' in sys.argv:
  processAllSpam = ''
else:
  processAllSpam = 'AND is:unread '
if '-s' in sys.argv:
  stockTo = sys.argv[sys.argv.index('-s')+1]
  useStockTo = True
else:
  useStockTo = False    
if '-autoTrashReports' in sys.argv:
  autoTrashReports = True
else:
  autoTrashReports = False    
if '-autoTrashSpam' in sys.argv:
  autoTrashSpam = True
else:
  autoTrashSpam = False
if '-autoTrashSec' in sys.argv:
  autoTrashSec = True
else:
  autoTrashSec = False
if '-autoTrashSec' in sys.argv:
  autoTrashSec = True
else:
  autoTrashSec = False
if '-automate' in sys.argv:
  automate = True
else:
  automate = False

#----- end no-sync zone

# and... action! Setup everything first...
# Create IMAP connection and try to login
ga = imaplib.IMAP4_SSL("imap.gmail.com")
try:
  ga.login(username, password)
except imaplib.IMAP4.error:
  print "Login failed. (Wrong username/password?)"
  raw_input("Exiting... Press Enter to Close")
  raise SystemExit
else:
  print "Login successful - "+username+' logged in'

if not os.path.exists(os.path.join(tempfile.gettempdir(),'downloaded_spam')):
  os.mkdir(os.path.join(tempfile.gettempdir(),'downloaded_spam'))
if not os.path.exists(os.path.join(tempfile.gettempdir(),'downloaded_stockjunk')):
  os.mkdir(os.path.join(tempfile.gettempdir(),'downloaded_stockjunk'))
date = datetime.datetime.today() + datetime.timedelta(days=-1)
date = imaplib.Time2Internaldate(date.timetuple())
date = date[:date.index(" ", 2)]+"\""
date = date.replace(" ", "")

# Check to see what language we are in
mb_names = []
mb_list = ga.list()
spam_mb = 'Spam'
mb_name = 'Gmail'
for item in mb_list[1]:
  mb_item = item.split('"')[3]
  if (mb_item[:7] == "[Gmail]"):
    mb_names.append(mb_item[8:])
  if (mb_item[:13] == "[Google Mail]"):
    mb_name = 'Google Mail'
    mb_names.append(mb_item[14:])
mb_names = mb_names[1:]
if verifyLang(mb_names,['Sent Mail', 'Spam', 'Trash']):
  # Must be English
  sent_mb = 'Sent Mail'
  trash_mb = 'Trash'
elif verifyLang(mb_names,['Corbeille', 'Messages envoy&AOk-s', 'Spam']):
  # Must be French
  sent_mb = 'Messages envoy&AOk-s'
  trash_mb = 'Corbeille'
elif verifyLang(mb_names,['Gesendet', 'Papierkorb', 'Spam']):
  # Must be German
  sent_mb = 'Gesendet'
  trash_mb = 'PapierKorb'
elif verifyLang(mb_names,['Enviados', 'Papelera', 'Spam']):
  # Must be Spanish
  sent_mb = 'Enviados'
  trash_mb = 'Papelera'   
elif verifyLang(mb_names,['Kosz', 'Spam', 'Wys&AUI-ane']):
  # Must be Polish
  sent_mb = 'Wys&AUI-ane'
  trash_mb = 'Kosz'
elif verifyLang(mb_names,['Cestino', 'Posta inviata', 'Spam']):
  # Must be Italian
  sent_mb = 'Posta inviata'
  trash_mb = 'Cestino'
elif verifyLang(mb_names,['L&AOQ-hetetyt viestit', 'Roskakori', 'Roskaposti']):
  # Must be Finnish
  spam_mb = 'Roskaposti'
  sent_mb = 'L&AOQ-hetetyt viestit'
  trash_mb = 'Roskakori'
elif verifyLang(mb_names,['Papperskorgen', 'Skickat mail', 'Skr&AOQ-ppost']):
  # Must be Swedish
  spam_mb = 'Skr&AOQ-ppost'
  sent_mb = 'Skickat mail'
  trash_mb = 'Papperskorgen'
elif verifyLang(mb_names,['Bin', 'Sent Mail', 'Spam']):
  # Must be UK English
  sent_mb = 'Sent Mail'
  trash_mb = 'Bin'
elif verifyLang(mb_names,['Prullenbak', 'Spam', 'Verzonden berichten']):
  # Must be Dutch
  sent_mb = 'Verzonden berichten'
  trash_mb = 'Prullenbak'
elif verifyLang(mb_names,['G&APY-nderilmi&AV8- Postalar', 'Spam', '&AMcA9g-p kutusu']):
  # Must be Turkish
  sent_mb = 'G&APY-nderilmi&AV8- Postalar'
  trash_mb = '&AMcA9g-p kutusu'
elif verifyLang(mb_names,['&W8RO9lCZTv0-', '&V4NXPpD1TvY-', '&V4NXPmh2-']):
  # Must be Traditional Chinese
  spam_mb = '&V4NXPpD1TvY-'
  sent_mb = '&W8RO9lCZTv0-'
  trash_mb = '&V4NXPmh2-'
elif verifyLang(mb_names,['Spam', 'Enviados', 'Lixeira']):
  # Must be Brazilian Portugese
  spam_mb = 'Spam'
  sent_mb = 'Enviados'
  trash_mb = 'Lixeira'
else:
  # Unknown Language
  print "Language is unknown and unsupported. Please send the authors this" + \
        " message and the following text. If possible, please include a" + \
        " translation."
  print mb_names
  raise SystemExit

if useStockTo:
  # Select the gmail Spam box
  ga.select('['+mb_name+']/'+spam_mb)
  
  # There is probably a slicker way to search for more than one item, but this
  # works.
  response, mail_list = ga.search(None, "BODY", "application/pdf", "SINCE", date)
  folder = mail_list[0].split()
  response, mail_list = ga.search(None, "BODY", "image/jpg", "SINCE", date)
  folder.extend( mail_list[0].split() )
  response, mail_list = ga.search(None, "BODY", "image/jpeg", "SINCE", date)
  folder.extend( mail_list[0].split() )
  response, mail_list = ga.search(None, "BODY", "image/gif", "SINCE", date)
  folder.extend( mail_list[0].split() )
  response, mail_list = ga.search(None, "BODY", "image/png", "SINCE", date)
  folder.extend( mail_list[0].split() )
  
  # Eliminate duplicates
  folder = list(set(folder))
  
  # Eliminate any read messages if "processAllSpam" flag is not set
  if processAllSpam != '':
    # Get list of unread messages
    response, unread = ga.search(None, "UNSEEN")
    # Messages comes down as space delimited list of message ids, all packed
    # into the first element of a list, so we need to split up the line to make
    # a proper list. This is done every time we use the "search" function.
    unread = unread[0].split()
    # loop through "folder" list and only include messages which are unread
    new_folder = []
    for item in folder:
      if item in unread:
        new_folder.append(item)
    # replace the old list with the unread-only list
    folder = new_folder
  
  total=len(folder)
  print ' '+str(total)+' (presumed) stockspam messages found in '+string.replace(spam_mb,'&','+').decode('utf-7').encode('utf-8')+' folder'
  i = 0
# download the junk
  for msg in folder:
    i = i + 1
    print " "*60+"\r", 
    print ' - downloading (presumed) stockspam message ('+str(i)+'/'+str(total)+')\r',
    sys.stdout.flush()
    f = open(nextAvailable('downloaded_stockjunk',msg,'txt'),'wb')
    # Get contents of message - 'RFC822' returns the entire message, including
    # the header. "fetch" returns a multi-dimensional list, and we are only
    # interested in the 2nd part of the 1st element, which is the contents of
    # the message
    response, message = ga.fetch(msg,'RFC822')
    # mark message as read (\\SEEN in IMAP's terminology)
    ga.store(msg,'+FLAGS', '\\SEEN')
    f.writelines(message[0][1])
    f.close()
  if (total>0):
    print ''

# then onto the rest of the junk
# Select the Gmail Spam box
ga.select('['+mb_name+']/'+spam_mb)
if processAllSpam == '':
  # Get all spam, not just Unread.
  response, folder = ga.search(None, "ALL", "SINCE", date)
else:
  # UNSEEN is IMAP-terminology for "Unread"
  response, folder = ga.search(None, "UNSEEN", "SINCE", date)
folder = folder[0].split()
total=len(folder)
print ' '+str(total)+' messages found in '+string.replace(spam_mb,'&','+').decode('utf-7').encode('utf-8')+' folder'
i = 0
# download the junk
for msg in folder:
  i = i + 1
  print " "*60+"\r", 
  print ' - downloading spam message ('+str(i)+'/'+str(total)+')\r',
  sys.stdout.flush()
  f = open(nextAvailable('downloaded_spam',msg,'txt'),'wb')
  # Get contents of message - 'RFC822' returns the entire message, including
  # the header. "fetch" returns a multi-dimensional list, and we are only
  # interested in the 2nd part of the 1st element, which is the contents of
  # the message
  response, message = ga.fetch(msg,'RFC822')
  # mark message as read (\\SEEN in IMAP's terminology)
  ga.store(msg,'+FLAGS', '\\SEEN')
  f.writelines(message[0][1])
  f.close()
if (total>0):
  print ''

# Then report the stockspam if necessary
if useStockTo:
  spamlist = os.listdir(os.path.join(tempfile.gettempdir(),'downloaded_stockjunk'))
  if (len(spamlist)>0):
    print ' Sending stockspam reports, '+str(maxReportSize)+' stockspam messages max per report'
  spamlist = os.listdir(os.path.join(tempfile.gettempdir(),'downloaded_stockjunk'))
  spamlistdirs = []
  for spam in spamlist:
    spamlistdirs.insert(0, os.path.join(tempfile.gettempdir(),'downloaded_stockjunk',spam))
  reports = 0
  if ((len(spamlist)%maxReportSize)==0):
    total = len(spamlist)/maxReportSize
  else:
    total = len(spamlist)/maxReportSize+1
  while (len(spamlistdirs)>0):
    names = []
    reportSize = 0
    for spam in spamlistdirs:
      names.append(spam)
      reportSize = reportSize + 1
      if reportSize >= maxReportSize:
        break
    try:
      # sendMail is defined above - it handles the message creation and sending.
      sendMail( [stockTo, toCC], 'spam report', '', names, 'smtp.gmail.com', username, password )
      print " "*60+"\r", 
      print ' - Sending report ('+str(reports)+'/'+str(total)+') containing '+str(reportSize)+' stockspam messages  \r', 
      sys.stdout.flush()
      for spam in names:
        os.remove(spam)
        spamlistdirs.remove(spam)
    except:
      print ' Reporting failed.'
      break
  if (len(spamlist)>0):
    print ""
  print '-- Summary :  '+str(reports)+' reports sent to '+stockTo
if os.path.exists(os.path.join(tempfile.gettempdir(),'downloaded_stockjunk')):
  try:
    os.rmdir(os.path.join(tempfile.gettempdir(),'downloaded_stockjunk'))
  except OSError:
    True

	
# print os.path.join(tempfile.gettempdir(),'downloaded_spam')
# raw_input("Press Enter to continue... ")
# shutil.copy('10.txt',os.path.join(tempfile.gettempdir(),'downloaded_spam'))
	
# Then report the other spam
spamlist = os.listdir(os.path.join(tempfile.gettempdir(),'downloaded_spam'))
if (len(spamlist)>0):
  print ' Sending spam reports, 20 spam messages max or 50KB attachments per report'
spamlistdirs = []
for spam in spamlist:
  spamlistdirs.insert(0, os.path.join(tempfile.gettempdir(),'downloaded_spam',spam))
# print spamlistdirs
reports = 0
if ((len(spamlist)%maxReportSize)==0):
  total = len(spamlist)/maxReportSize
else:
  total = len(spamlist)/maxReportSize+1
while (len(spamlistdirs)>0):
  names = []
  reportSize = 0
  reportFileSize = 0
  for spam in spamlistdirs:
    if (((reportFileSize + os.path.getsize(spam))/1024) < 51) and (reportSize < 20):
      names.append(spam)
      reportSize = reportSize + 1
      reportFileSize = reportFileSize + os.path.getsize(spam)
    if (names == []) and ((os.path.getsize(spam)/1024) > 50):
      names.append(spam)
      reportSize = 1
      reportFileSize = os.path.getsize(spam)
    if (reportSize==20) or ((reportFileSize/1024) > 50) or (((reportFileSize + os.path.getsize(spam))/1024) > 50):
      break
  try:
    # sendMail is defined above - it handles the message creation and sending.
    sendMail([to,toCC], 'spam report', '', names, 'smtp.gmail.com', username, password )
    reports = reports + 1
    print " "*60+"\r", 
    print ' - Sending report '+str(reports)+' containing '+str(reportSize)+' spam messages  \r', 
    sys.stdout.flush()
    for spam in names:
      os.remove(spam)
      spamlistdirs.remove(spam)
  except(smtplib.SMTPDataError):
    print " Reporting failed because GMail rejected the attachment, deleting this report"
    for spam in names:
      os.remove(spam)
      spamlistdirs.remove(spam)
  except:
    print ' Reporting failed because of an unknown error.'
    break
if (len(spamlist)>0):
  print ""
print '-- Summary :  '+str(reports)+' reports sent to knuj0n'
if os.path.exists(os.path.join(tempfile.gettempdir(),'downloaded_spam')):
  try:
    os.rmdir(os.path.join(tempfile.gettempdir(),'downloaded_spam'))
  except OSError:
    True


# reports clean up from sent mail
# Select the Gmail Sent Mail box.
ga.select('['+mb_name+']/' + sent_mb)
# Search for any messages with the Subject: spam report and the
# To: <spam reporting address>
response, folder = ga.search(None, "SUBJECT", 'spam report', "TO", to)
folder = folder[0].split()
stockfolder = []
if useStockTo:
  # Search for any messages with the Subject: stockspam report and the
  # To: <stock spam reporting address>
  response, stockfolder = ga.search(None, "SUBJECT", 'stockspam report', "TO", stockTo)
  stockfolder = stockfolder[0].split()

print "- There are "+str(len(folder)+len(stockfolder))+" spam reports in your "+string.replace(sent_mb,'&','+').decode('utf-7').encode('utf-8')
if (len(folder)+len(stockfolder))>0:
  next = 'y'
  if not autoTrashReports:
    if automate:
      next = 'n'
    else:
      next = raw_input(" Trash the spam reports? (y/n) \n or Press Enter to quit: ")
    if next=='':
      raise SystemExit
  if (next=='y'):
    i = 0
    total = len(folder)+len(stockfolder)
    for msg in stockfolder:
      i = i + 1
      print " "*60+"\r", 
      print " Trashing spam report: ("+str(i)+"/"+str(total)+")\r",
      sys.stdout.flush()
      # To move a message using IMAP, we first copy it to the trash folder,
      # then set it's flag to /DELETE. Finally, expunge the messages to delete
      # them from the server.
      # NOTE: cutting out the copy would save time - do we really want this
      #       item moved into the Trash folder???
      ga.copy(msg,'['+mb_name+']/'+trash_mb)
      ga.store(msg,'+FLAGS', '\\Deleted')
    for msg in folder:
      i = i + 1
      print " "*60+"\r", 
      print " Trashing spam report: ("+str(i)+"/"+str(total)+")\r",
      sys.stdout.flush()
      ga.copy(msg,'['+mb_name+']/'+trash_mb)
      ga.store(msg,'+FLAGS', '\\Deleted')
    # Expunge all deleted messages. Until this command, the deleted messages
    # are just flagged for deletion... this will remove them for good.
    ga.expunge()
    print ""

# INBOX clean up (enforcement notifications)
# Select the main mailbox (Inbox)
ga.select()
response, folder = ga.search(None, "SUBJECT", 'Delivery Notification / Enforcement Complaint Response', "FROM", 'enforcement@sec.gov')
folder = folder[0].split()
print "- There are "+str(len(folder))+" SEC-delivery notifications in your inbox"
if len(folder)>0:
  next = 'y'
  if not autoTrashSec:
    if automate:
      next = 'n'
    else:
      next = raw_input(" Clean Inbox? (y/n) \n or Press Enter to quit: ")
    if next=='':
      raise SystemExit
  if (next=='y'):
    i = 0
    total = len(folder)
    for msg in folder:
      i = i + 1
      print " "*60+"\r", 
      print " trashing ("+str(i)+"/"+str(total)+") :   "+msg.subject[:30]+"...\r",
      sys.stdout.flush()
      # To move a message using IMAP, we first copy it to the trash folder,
      # then set it's flag to /DELETE. Finally, expunge the messages to delete
      # them from the server.
      # NOTE: cutting out the copy would save time - do we really want this
      #       item moved into the Trash folder???
      ga.copy(msg,'['+mb_name+']/'+trash_mb)
      ga.store(msg,'+FLAGS', '\\Deleted')      
    # Expunge all deleted messages. Until this command, the deleted messages
    # are just flagged for deletion... this will remove them for good.
    ga.expunge()
    print ""
		
# spam folder clean up
# Select the Gmail Spam box
ga.select('['+mb_name+']/'+spam_mb)
# Search for all read messages. Ignore unread, since they might have arrived
# after our script started running.
response, folder = ga.search(None, "SEEN", "SINCE", date)
folder = folder[0].split()
# gmail drops the message as soon as the flag is set to delete, so we need to
# sort the list in reverse so that the highest number gets dropped first. This
# is likely to be a bug in gmail, but this fix shouldn't break even if they fix
# the bug.
folder.reverse()
print "- There are "+str(len(folder))+" processed messages in your "+spam_mb+" folder"
if len(folder)>0:
  next = 'y'
  if not autoTrashSpam:
    if automate:
      next = 'n'
    else:
      next = raw_input(" Delete processed spam? (y/n) \n or Press Enter to quit: ")
    if next=='':
      raise SystemExit
  if (next=='y'):
    i = 0
    total = len(folder)
    subject_re = re.compile("Subject: (.*)")
    for msg in folder:
      i = i + 1
      print " "*60+"\r", 
      header = ga.fetch(msg,'RFC822.HEADER')
      header = header[1][0][1]
      subject = subject_re.search(header)
      if subject:
        subject = subject.group(1)
      else:
        subject = ''
      if (len(subject)>0):
        subject=subject[:len(subject)-1]
      print " trashing ("+str(i)+"/"+str(total)+"):   "+subject[:50]+"...\r",
      sys.stdout.flush()
      # To move a message using IMAP, we first copy it to the trash folder,
      # then set it's flag to /DELETE. Finally, expunge the messages to delete
      # them from the server.
      # NOTE: cutting out the copy would save time - do we really want this
      #       item moved into the Trash folder???
      ga.copy(msg,'['+mb_name+']/'+trash_mb)
      ga.store(msg,'+FLAGS', '\\Deleted')      
    # We don't technically need to do this in gmail, since stuff in the spam
    # folder gets deleted as soon as it is marked. Doing the expunge anyway
    # won't hurt anything, and will avoid relying on the special behavior of the
    # Spam box if they ever "fix" it to work in the standard way.
    ga.expunge()
    print ""
# Close out and clean up the mailbox
ga.close()
# Logout of IMAP server
ga.logout()
if not automate:
  raw_input("Press Enter to quit... ")
