Hours of searching lead to frustration, frustration leads to overdue creation, creation leads to the dark side of the spam.  die spam, die (it's german ;-) )

BlueFrog is dead.  Okopipi doesn't produce mucho.  But knujon actually wants all of our junkmail and tells us the spammers' days are counted.  And so does spamcop. My GMail-account catches a lot of spam, yet there was no easy way to report tons of spam in the spam folder of my gmail account. Python, libgmail and a bucket full of persistence, not solely my own, gave birth to this script.

This is basically the same script as gknujon, except that it only reports 48hrs old spam, instead of doing a lot of filtering and putting it all in one script I decided to split them up.  Since I figured there must be a lot of knujon users who don't use spamcop and/or vice versa.

Mail any suggestions to rainwolf@submanifold.be, 
have fun

INSTRUCTIONS
************
- run "StandAlone_gspamcop -h" for a list of all the parameters and instructions
- There's a sample line in gspamcop.bat
- For multiple accounts simply add similar lines to the .bat file

- The idea, at least for people who use spamcop and knujon, is to run this first, so that all the fresh spam gets picked out, which can be reported to knujon and spamcop in one go, then run gknujon for the rest.