This Mathematica implementation enables you to efficiently compute the alibi query of two space-time prisms.

This implementation is available at http://othmanw.submanifold.be 