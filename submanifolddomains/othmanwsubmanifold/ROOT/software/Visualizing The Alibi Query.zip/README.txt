This Mathematica implementation enables you to visualize space-time prisms
and their intersections and projections on roadnetworks.
Use GraphEditor.jar to make your own roadnetwork first, this software is available at
http://www.cs.sunysb.edu/~skiena/combinatorica/grapheditor/download.html
then paste the output in the notebook file.
p,q are nodes in the network, tp is a departure time, and tq is the time to arrive in q.
speedlimits can be any set of speedlimits, these will be assigned randomly to the edges in 
the roadnetwork. That is why space-time prisms always look different even though you don't change the 
parameters. You can also make a list of just one speedlimit, then a space-time prism of 
a moving object whose maximal speed is that speedlimit will be drawn.

You will also need IMTek's Mathemathica Supplement, available at
http://www.imtek.uni-freiburg.de/simulation/mathematica/IMSweb/

This implementation will only work for Mathematica 6, to make this work on
Mathematica 5.2, remove the Opacity directives.

This implementation is available at http://othmanw.submanifold.be